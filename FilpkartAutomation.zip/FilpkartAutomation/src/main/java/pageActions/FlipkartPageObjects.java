package pageActions;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import junit.framework.Assert;

public class FlipkartPageObjects {

	WebDriver driver;
	String curWindow;
	String pdpAmountVal;
	String ordersumVal;

	public FlipkartPageObjects(WebDriver driver) {
		super();
		this.driver = driver;
	}
	By searchBox=By.name("q");
	By searchBtn=By.xpath("//*[@class='L0Z3Pu']");
	By mobileLink=By.xpath("//*[contains(text(),'realme C20 (Cool Grey, 32 GB)')]/preceding::img[@alt='realme C20 (Cool Grey, 32 GB)']");
	By addToCartLink=By.xpath("//[contains(text(),'ADD TO CART')]");
	
	public void searchkeyword(String keyword) {
		driver.findElement(By.xpath("//*[@class='_2QfC02']/button")).click();
		driver.findElement(searchBox).sendKeys(keyword);
		driver.findElement(searchBtn).click();
	}
	
	public void clciksonFirstSearchResult() {
		driver.findElement(mobileLink).click();
		
	}
	public void move_to_PDP() {
		pdpAmountVal=driver.findElement(By.xpath("//*[@class='_30jeq3 _16Jk6d']")).getText();
		 curWindow=driver.getWindowHandle();
		Set<String>windows=driver.getWindowHandles();
		System.out.println("Size"+windows.size());	
	
		for(String curWindows:windows) {
			if(curWindows!=curWindow){
				driver.switchTo().window(curWindows);
				break;
			}
		}
	}
	
	public void addToCart() {
		driver.findElement(addToCartLink).click();
	}
	
	public void fetchAmountInOrderSummary() {
		ordersumVal=driver.findElement(By.xpath("//*[contains(text(),'Total Amount')]//following::div/span")).getText();
	}
	
	public void vlidatePrice() {
		Assert.assertEquals(pdpAmountVal, ordersumVal);
		if(ordersumVal.equalsIgnoreCase(pdpAmountVal)) {
			System.out.println("Price same");
			
		}else {
			System.out.println("Price same");
			
		}
	}
	
}
