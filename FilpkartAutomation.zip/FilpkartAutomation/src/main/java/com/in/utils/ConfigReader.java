package com.in.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class ConfigReader {
	Properties props;
	WebDriver driver;

	public Properties initConfigFile() throws IOException {
		Properties props = new Properties();
		File file = new File("src/test/resources/config.properties");
		FileInputStream fis = new FileInputStream(file);
		props.load(fis);
		return props;

	}

}
