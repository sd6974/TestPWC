package test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JavaProg {
	public static void main(String args[]) {

		int arr[] = { 10, 15, 0, 16, 19, 0, 20, 0, 21 };
		int arr2[] = new int[5];
		List<Integer> integrs = new ArrayList<Integer>();
		int count = 0;
		List<Integer> finalList = new ArrayList<Integer>();
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == 0) {
				count++;
			}
			integrs.add(arr[i]);

		}
		Iterator it = integrs.iterator();
		while (it.hasNext()) {
			int i = (int) it.next();
			if (i ==0) {
				it.remove();
				
			}
			System.out.println(it);
		}
	}

}
