package steps;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.in.utils.ConfigReader;
import com.in.utils.DriverFactory;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class GlobalHooks {
	WebDriver driver;
	Properties props;
	
	
	@Before(order=0)
	public void initConfigFile() throws IOException {
		ConfigReader reader=new ConfigReader();
		props=reader.initConfigFile();	
	}

	@Before(order=1)
	public void initBrowser() throws IOException {
		DriverFactory driverfactory=new DriverFactory();
		driver=driverfactory.initBrowser(props.getProperty("browser"));
	}
	
	@After(order=0)
	public void tearDown() {
		driver.quit();
	}
	
	@After(order=1)
	public void attachScreesnhot(Scenario scenario) {
		String scenarioName=scenario.getName().replaceAll(" ", "_");
		byte[]screesnhot=((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
		scenario.embed(screesnhot, "image/png", scenarioName);
		
	}
	
}
