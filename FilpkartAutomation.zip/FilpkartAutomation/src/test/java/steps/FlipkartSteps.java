package steps;

import java.io.IOException;

import com.in.utils.DriverFactory;
import com.in.utils.ExcelReader;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

import pageActions.FlipkartPageObjects;

public class FlipkartSteps {
	
	FlipkartPageObjects po=new FlipkartPageObjects(DriverFactory.getDriver());
	
	
	@Given("User lauches the application retrieving sheetName \"([^\"]*)\" and rowNumber \"([^\"]*)\"")
	public void user_lauches_the_application_retrieving_sheetName_and_rowNumber(String sheetName, Integer rowNum) throws IOException {
	    ExcelReader reader=new ExcelReader();
	    String url=reader.readFromExcel("./src/test/resources/TestData.xlsx", sheetName, rowNum);
	    DriverFactory.getDriver().get(url);  
	    
	    
	}
	
	
	@Given("User searches \"([^\"]*)\" as a search key word")
	public void user_searches_as_a_search_key_word(String keyword) {
	    po.searchkeyword(keyword);
	}

	@Given("user clicks on the first serach result")
	public void user_clicks_on_the_first_serach_result() {
		po.clciksonFirstSearchResult();
	}

	@When("User moves to the PDP page and fetches the price")
	public void user_moves_to_the_PDP_page_and_fetches_the_price() {
	   po.move_to_PDP();
	}

	@Then("User adds product to cart")
	public void user_adds_product_to_cart() {
	   po.addToCart();
	}


	@Then("User fetches the total amount")
	public void user_fetches_the_total_amount() {
	    po.fetchAmountInOrderSummary();
	}

	@Then("the price should be validated")
	public void the_price_should_be_validated() {
	    po.vlidatePrice();
	}

	
}
